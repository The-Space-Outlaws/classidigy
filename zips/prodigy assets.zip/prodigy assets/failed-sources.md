# Missing Prodigy assets

These four manifest entries could not be downloaded from public sources reachable from this workspace:

- `images/pets/13.png`
- `images/pets/13.json`
- `images/education/manipulatives.png`
- `images/education/manipulatives.json`

Observed results:

- Official CDN URLs under `https://cdn.prodigygame.com/game/assets/...` return HTTP 403 `AccessDenied` (AmazonS3/CloudFront), even with a Prodigy referer.
- `https://daboss7173.github.io/oldprodigy/1-30-0/assets/...` returns HTTP 404 for all four.
- Public GitHub mirrors checked (`JBX2060/ProdigyAssets`, `DenisDziganchuk/ProdigyAssets`) do not contain these paths.
- Wayback CDX shows no archived copies of these exact URLs.

Do not substitute unrelated `13.png` files (monsters/player/hats/outfits/weapons exist, but not `images/pets/13.*`). If you have a local Prodigy 1.30.0 install, cache, or dump that still contains these files, place them at the paths above.
